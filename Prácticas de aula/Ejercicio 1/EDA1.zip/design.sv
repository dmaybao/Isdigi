module SHIFTER
  (	input wire	clk, ES, reset,
	output wire SS);
reg [3:0] SHIFT;

  
always @(negedge reset, posedge clk)
if (!reset)
  SHIFT <= 4'H0;
else
  begin
    SHIFT[3]<=ES;
    SHIFT[2]<=SHIFT[3];
    SHIFT[1]<=SHIFT[2];
    SHIFT[0]<=SHIFT[1];
  end
  

assign SS=SHIFT[0];
  

 //zona de autochequeo con aserciones 
property desplazamiento;
   @(posedge clk) disable iff(reset!=1'b1) s1;
endproperty
  desplazar:assert property  (desplazamiento) else $error("Autochequeo: el shifter no es de 4 etapas");     
    
sequence s1;
  logic aux;
  (1, aux=ES) ##4  (SS==aux);
endsequence
 
endmodule
