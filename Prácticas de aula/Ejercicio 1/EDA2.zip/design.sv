module Contador  #(parameter n = 4)
  (input clk, incr,areset_n, sreset_n,load,up_down ,
   input [n-1:0] dato, 
   output reg [n-1:0] salida,
   output TC );

  

//localparam width_counter=4;
  wire  [n-1:0] fin_cuenta= up_down?2**n-1:0;



  assign TC=(salida==fin_cuenta)?1'b1:1'b0;
always @(posedge clk or negedge areset_n)
  if (!areset_n)
        salida<=0;
	else
	  	if (sreset_n==1'b0)
    		salida<=0;
  		else
          if(load)
            salida<=dato;
           else
             if (incr)
               if(up_down)
				 salida<=salida+1;
  			   else
                 salida<=salida-1;



  sequence s1;
  logic [n-1:0]  aux;
    (1, aux=salida)  ##1 (salida==aux+1'b1);
endsequence  
  sequence s2;
  logic [n-1:0]  aux;
    (1, aux=salida)  ##1 (salida==aux-1'b1);
endsequence    
  prueba1:  assert property (@(posedge clk) disable iff (areset_n===1'bx ||areset_n==1'b0 ) load==1'b0&&incr==1'b1&&up_down==1'b1&&sreset_n==1'b1|->s1) else $error("el contador va mal");
prueba2:  assert property (@(posedge clk) disable iff (areset_n!=1'b1) load==1'b0&&incr==1'b1&&up_down==1'b1&&sreset_n==1'b1|=>salida==$past(salida)+1'b1) else $error("el contador va mal2");  
prueba3:  assert property (@(posedge clk) disable iff (areset_n!=1'b1) load==1'b0&&incr==1'b1&&up_down==1'b0&&sreset_n==1'b1|->s2) else $error("el contador va mal3");
prueba4:  assert property (@(posedge clk) disable iff (areset_n!=1'b1) load==1'b0&&incr==1'b1&&up_down==1'b0&&sreset_n==1'b1|=>salida==$past(salida)-1'b1) else $error("el contador va mal4");  
  
  
endmodule




