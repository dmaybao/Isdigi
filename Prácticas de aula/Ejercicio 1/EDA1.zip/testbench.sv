// Code your testbench here
// or browse Examples
`timescale 1 ns / 1 ps


module Shifter_basico_tb  ; 
localparam T=50;
localparam Thold=5;
localparam Td=10;
localparam Tsetup=5;
wire out   ;
reg reg_out;
reg    clk   ; 
reg    reset   ; 
reg    in   ; 
  SHIFTER    DUT  ( 
     .SS (out ) ,
     .clk (clk  ) ,
     .reset (reset ) ,
     .ES (in ) ); 

initial begin clk = 1'b0;
forever #(T/2)  clk = !clk;
end
  always@(out)
    reg_out=out;
initial begin
  $dumpfile("FSM.vcd");
  $dumpvars(0,Shifter_basico_tb.DUT);
end  
initial
begin
	$warning("SIMULANDO!!!");  
  	in=1'b0;
	# (T*5);                    
  	$warning("VERIFICACION 1 desplazamiento de un UNO");     CASO_1(); 
 	#(T*5);
    $finish;
	end                                                    

task CASO_1;
	begin
      @(negedge clk) reset = 1'b0;
      @(negedge clk) reset  = 1'b1;
	  in=1'b1;
      @(negedge clk) in=1'b0;
      repeat (2) 	@(negedge clk);                                       		       comprueba_vector_2pos(reg_out,clk, 1'b1);			
	end
endtask



  
task automatic comprueba_vector_2pos;
ref  datos_sal_obtenido;
ref  reloj;  
input  datos_sal_esperado;
begin
  @(posedge reloj); 
  #(T-Tsetup);
  if(datos_sal_obtenido !== datos_sal_esperado)
    $error ("Tesbecnh: El shifter no da un retardo de 4 etapas");       
  else 
       fork: espero_no_cambio
         @(datos_sal_obtenido) $error ("fallo setup");
         @(posedge reloj)  disable espero_no_cambio;                  
       join
end
endtask  

endmodule