// Verilog for Hardware Synthesis
// 

// Author: Gadea Gironés, Rafael
// Date:   06-Feb-2016

// Code your testbench here
// or browse Examples
`timescale 1 ns / 1 ps


module Contador_tb  ; 
localparam Tamanyo=5;
localparam T=100;
  reg   [Tamanyo-1:0] entrada;
  reg clk,areset_n,sreset_n, cargar,contar,up_down;
  wire finalizar;
  wire [Tamanyo-1:0] Salida;
  wire finalizar_ref;
  wire [Tamanyo-1:0] Salida_ref;
  
  //aqui instanciamos nuestro diseño bajo test (dut)
Contador #(.n(Tamanyo)) 
   dut  ( 
     .areset_n (areset_n ) ,
     .clk (clk ) ,
     .sreset_n (sreset_n ) ,
     .dato (entrada ),
     .up_down(up_down),
     .incr(contar),
     .load(cargar),
     .salida(Salida),
     .TC(finalizar)
   ); 

initial
  begin
  $dumpfile("contador.vcd");
    $dumpvars(0,Contador_tb);
end 

initial begin clk = 1'b0;
forever #(T/2)  clk = !clk;
end

  
initial
begin
  $warning("SIMULANDO!!!");  	
  areset_n=1'b1;
  sreset_n=1'b1;
  cargar=1'b0;
  contar=1'b0;
  entrada=5'd25;
  up_down=1'b1; //modo up
  # (T);  
  areset_n=1'b0;
  # (T);
  areset_n=1'b1;
  # (T*5);   
  $warning("VERIFICACION 1 modo incrementar y compruebo TC modo up");
  CASO_1(); // Caso de Verificacion 1. SECUENCIA NORMAL	
  #(T*5);
  $warning("VERIFICACION 2 modo cargar y reset síncrono modo up");  
  CASO_2(); // Caso de Verificacion 2. Casos especiales
  # (T*5);
  up_down=1'b0; //ponemos modo down
  $warning("VERIFICACION 1 modo incrementar y compruebo TC modo down");
  CASO_1(); // Caso de Verificacion 1. SECUENCIA NORMAL	
  #(T*5);
  $warning("VERIFICACION 2 modo cargar y reset síncrono modo down");  
  CASO_2(); // Caso de Verificacion 2. Casos especiales  
  $finish;
end                                                    

  //aqui instanciamos nuestro diseño de referencia
  
  contador_ref #(.n(Tamanyo)) 
   golden_model  ( 
     .areset_n (areset_n ) ,
     .clk (clk ) ,
     .sreset_n (sreset_n ) ,
     .dato (entrada ),
     .incr(contar),
     .up_down(up_down),
     .load(cargar),
     .salida(Salida_ref),
     .TC(finalizar_ref)
   );

  always@(negedge clk)
    begin
      if (Salida!==Salida_ref)
        $error("error en el comportamiento de la salida");
      if (finalizar!==finalizar_ref)
        $error("error en el comportamiento del fin de cuenta"); 
    end  
  
task CASO_1;
	begin
      @(negedge clk) contar = 1'b1;
      repeat (40) 	@(negedge clk);
	  contar=1'b0;		
	end
endtask


task CASO_2;
  begin
    @(negedge clk) cargar = 1'b1;
    repeat (4) 	@(negedge clk);
    sreset_n=1'b0;
    @(negedge clk) sreset_n  = 1'b1;
    repeat (4) 	@(negedge clk);
    contar  = 1'b1;
    repeat (4) 	@(negedge clk);
    cargar=1'b0;
    repeat (4) 	@(negedge clk);
    sreset_n=1'b0;
    @(negedge clk) sreset_n  = 1'b1;
    repeat (4) 	@(negedge clk);
    contar=1'b0;
    repeat (4) 	@(negedge clk);    
	end
endtask
  
 
endmodule



module contador_ref  #(parameter n = 4)
  (input clk, incr,areset_n, sreset_n,load, up_down,
   input [n-1:0] dato, 
   output [n-1:0] salida,
   output TC );
  wire [n-1:0] aux1,aux2,aux3;
  multiplexor #(.size(n))   U3
  (.select(load),
   .entrada1(dato),
   .entrada2(aux2),
   .salida(aux3));
  sumador_restador #(.size(n))  U1 
  ( .dataa(aux1),
   .datab(1),
   .add_sub(up_down),
   	.result(aux2));
  registro   #(.size(n))    U2 
  	(.clk(clk),
     .areset_n(areset_n),
     .sreset(~sreset_n),
     .d(aux3),
     .q(aux1),
     .enable(incr|load));
  
  assign TC=up_down?&aux1:~|aux1;
  assign salida=aux1;
  
endmodule



module sumador_restador #(parameter size = 4) (
  input  [size -1:0] dataa,
  input  [size -1:0] datab,
  input add_sub,
  output reg [size-1:0] result  );

  always @(dataa,add_sub)
    if (add_sub)
  		result=dataa+datab;
  	else
        result=dataa-datab;

endmodule

module multiplexor  #(parameter size = 4) 
  (input select,
   input [size-1:0] entrada1,
   input [size-1:0] entrada2,
   output [size-1:0] salida);
  assign salida=select?entrada1:entrada2;
endmodule


module registro #(parameter size = 4) 
  ( input clk, enable,areset_n, sreset, input [size-1:0] d, output reg [size-1:0] q);
  always @(posedge clk or negedge areset_n)
    if (!areset_n)
      q <= 0;
    else
      if (sreset==1'b1)
          q<=0;
       else
         if (enable==1'b1)
           q <= d;
endmodule



